﻿using UnityEngine;
using UnityEngine.Events;
using UnityEngine.InputSystem;

public class PlayerHearts : MonoBehaviour
{
    public int maxHearts = 3;
    public int currentHearts;
    public float invulnerableTime = 0.5f;

    public UnityEvent<int, int> OnHealthChanged;

    private float invulnerableUntil;

    void Start()
    {
        currentHearts = maxHearts;
        OnHealthChanged.Invoke(currentHearts, maxHearts);
    }

    void Update()
    {
        if (Keyboard.current != null && Keyboard.current.pKey.wasPressedThisFrame)
        {
            LoseHeart();
        }
    }

    public void LoseHeart()
    {
        if (currentHearts <= 0) return;
        if (Time.time < invulnerableUntil) return;

        invulnerableUntil = Time.time + invulnerableTime;

        currentHearts--;
        OnHealthChanged.Invoke(currentHearts, maxHearts);
        Debug.Log("Serduszka: " + currentHearts);

        if (currentHearts == 0)
        {
            Debug.Log("Gracz zginął!");
        }
    }
}
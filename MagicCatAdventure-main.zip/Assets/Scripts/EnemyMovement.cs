using UnityEngine;

public class EnemyMovement : MonoBehaviour
{
    [SerializeField] private float moveSpeed = 2f;
    [SerializeField] private float stopDistance = 0.8f;
    [SerializeField] private float retreatDistance = 0f;
    [SerializeField] private string playerTag = "Player";
    [SerializeField] private Animator animator;
    [SerializeField] private SpriteRenderer spriteRenderer;

    private static readonly int IsMovingHash = Animator.StringToHash("isMoving");

    private Transform player;

    private void Start()
    {
        GameObject playerObj = GameObject.FindGameObjectWithTag(playerTag);
        if (playerObj != null)
            player = playerObj.transform;

        if (animator == null)
            animator = GetComponent<Animator>();

        if (spriteRenderer == null)
            spriteRenderer = GetComponent<SpriteRenderer>();
    }

    private void Update()
    {
        if (player == null) return;

        Vector2 toPlayer = (Vector2)player.position - (Vector2)transform.position;
        float distance = toPlayer.magnitude;

        Vector2 moveDirection = Vector2.zero;
        bool moving = false;

        if (retreatDistance > 0f && distance < retreatDistance && distance > 0.01f)
        {
            moveDirection = -toPlayer.normalized;
            moving = true;
        }
        else if (distance > stopDistance)
        {
            moveDirection = toPlayer.normalized;
            moving = true;
        }

        if (moving)
            transform.position += (Vector3)(moveDirection * moveSpeed * Time.deltaTime);

        if (spriteRenderer != null && Mathf.Abs(toPlayer.x) > 0.01f)
            spriteRenderer.flipX = toPlayer.x < 0;

        if (animator != null)
            animator.SetBool(IsMovingHash, moving);
    }
}

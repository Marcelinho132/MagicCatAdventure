using UnityEngine;

public class MageShockwave : MonoBehaviour
{
    [SerializeField] private float speed = 5f;
    [SerializeField] private float explodeRadius = 1.4f;
    [SerializeField] private float explodeTime = 0.5f;
    [SerializeField] private string playerTag = "Player";

    private Vector2 target;
    private Vector2 moveDirection;
    private bool exploding;
    private bool damaged;
    private float explodeElapsed;
    private SpriteRenderer spriteRenderer;
    private Vector3 baseScale;
    private Transform player;

    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        baseScale = transform.localScale;
    }

    public void SetBolt(Sprite boltSprite)
    {
        if (spriteRenderer != null)
            spriteRenderer.sprite = boltSprite;
    }

    public void Cast(Vector2 targetPosition)
    {
        transform.SetParent(null);
        target = targetPosition;

        moveDirection = (targetPosition - (Vector2)transform.position).normalized;

        float angle = Mathf.Atan2(moveDirection.y, moveDirection.x) * Mathf.Rad2Deg;
        transform.rotation = Quaternion.Euler(0, 0, angle);
    }

    private void Update()
    {
        if (!exploding)
        {
            float step = speed * Time.deltaTime;
            float remaining = Vector2.Distance(transform.position, target);

            if (remaining <= step)
            {
                transform.position = target;
                StartExplosion();
            }
            else
            {
                transform.position += (Vector3)(moveDirection * step);
            }
        }
        else
        {
            UpdateExplosion();
        }
    }

    private void StartExplosion()
    {
        exploding = true;
        explodeElapsed = 0f;
    }

    private void UpdateExplosion()
    {
        explodeElapsed += Time.deltaTime;
        float t = Mathf.Clamp01(explodeElapsed / explodeTime);

        float scaleFactor = Mathf.Lerp(0.3f, explodeRadius * 2f, t);
        transform.localScale = baseScale * scaleFactor;

        if (!damaged && t > 0.15f && PlayerInRadius(explodeRadius * t))
        {
            damaged = true;
            PlayerHearts hearts = GetPlayerHearts();
            if (hearts != null)
                hearts.LoseHeart();
        }

        if (t >= 1f)
            Destroy(gameObject);
    }

    private bool PlayerInRadius(float radius)
    {
        Transform p = GetPlayer();
        return p != null && Vector2.Distance(transform.position, p.position) <= radius;
    }

    private PlayerHearts GetPlayerHearts()
    {
        Transform p = GetPlayer();
        return p != null ? p.GetComponent<PlayerHearts>() : null;
    }

    private Transform GetPlayer()
    {
        if (player == null)
        {
            GameObject playerObj = GameObject.FindGameObjectWithTag(playerTag);
            if (playerObj != null)
                player = playerObj.transform;
        }
        return player;
    }
}

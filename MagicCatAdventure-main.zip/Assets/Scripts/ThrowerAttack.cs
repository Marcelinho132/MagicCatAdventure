using UnityEngine;

public class ThrowerAttack : MonoBehaviour
{
    [SerializeField] private GameObject bombPrefab;
    [SerializeField] private Transform spawnPoint;
    [SerializeField] private float attackRange = 6f;
    [SerializeField] private float cooldown = 1.5f;
    [SerializeField] private string playerTag = "Player";

    private Transform player;
    private float nextAttackTime;

    private void Start()
    {
        GameObject playerObj = GameObject.FindGameObjectWithTag(playerTag);
        if (playerObj != null)
            player = playerObj.transform;
    }

    private void Update()
    {
        if (player == null || bombPrefab == null) return;
        if (Time.time < nextAttackTime) return;

        Vector2 toPlayer = (Vector2)player.position - (Vector2)transform.position;
        if (toPlayer.magnitude > attackRange) return;

        Attack();
    }

    private void Attack()
    {
        nextAttackTime = Time.time + cooldown;

        Vector3 spawnPos = spawnPoint != null ? spawnPoint.position : transform.position;
        GameObject bombObj = Instantiate(bombPrefab, spawnPos, Quaternion.identity);

        Bomb bomb = bombObj.GetComponent<Bomb>();
        if (bomb == null)
        {
            Debug.LogError("Prefab bomby nie ma skryptu Bomb!");
            Destroy(bombObj);
            return;
        }

        bomb.Throw(player.position);
    }
}

using System.Collections;
using UnityEngine;

public class EnemyHealth : MonoBehaviour
{
    [SerializeField] private int maxHp = 3;
    [SerializeField] private float hitFlashTime = 0.1f;

    private int currentHp;
    private SpriteRenderer spriteRenderer;
    private Color baseColor;

    private void Start()
    {
        currentHp = maxHp;
        spriteRenderer = GetComponent<SpriteRenderer>();
        if (spriteRenderer != null)
            baseColor = spriteRenderer.color;
    }

    public void TakeDamage(int damage)
    {
        currentHp -= damage;

        if (spriteRenderer != null)
            StartCoroutine(Flash());

        if (currentHp <= 0)
            Destroy(gameObject);
    }

    private IEnumerator Flash()
    {
        spriteRenderer.color = Color.red;
        yield return new WaitForSeconds(hitFlashTime);
        if (spriteRenderer != null)
            spriteRenderer.color = baseColor;
    }
}
